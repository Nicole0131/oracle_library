<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="shortcut icon" href="favicon.ico" />
<title>�������</title>
<link href="lms.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
  <tr height="256">
    <td colspan="6"><img src="pics/banner.png" width="796" height="254"></td>
  </tr>
  <tr height="50">
    <td width="100"><div class="button"><li><a href="library.php"><b>��ҳ</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="search.php"><b>����ͼ��</b></a></li>
    </div></td>
	 <td width="130"><div class="button"><li><a href="login.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="bookmanage.php"><b>ͼ�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="usermanage.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="recordmanage.php"><b>���Ĺ���</b></a></li>
    </div></td>
  </tr>
</table>
</center>

<center>
<?php
	@$bookname = $_POST['bookname'];
	@$author = $_POST['author'];
	@$keyword = $_POST['keyword'];
	if(($bookname == "") && ($author == "") && ($keyword == ""))
	{
		@$bookname = $_GET['bookname'];
		@$author = $_GET['author'];
		@$keyword = $_GET['keyword'];
	}
	require_once "dbaccess.php";	
	$querywhere = " where 1='1'";
	if($bookname != ""){ $querywhere = $querywhere."and BookName="."\"".$bookname."\""; }
	if($author != ""){$querywhere = $querywhere."and Author like'%".$author."%'";}
	if($keyword != ""){$querywhere = $querywhere."and BookName like'%".$keyword."%'";}
	$query = "select * from books".$querywhere;
	$result = mysql_query($query);
	$rows_total = @mysql_num_rows($result);
	@$page_no = $_GET['page_no'];
		
		@$page_no = $_GET['page_no'];//ÿҳ��¼��
		$page_num = 10;//ÿҳ��¼��
		$page_total = floor($rows_total/10);//������ҳ��
		if($rows_total%10!=0)
		{
			$page_total=$page_total+1;
		}
		if($page_no>$page_total)
		{
			$page_no = $page_total;
		}
		if(!$page_no)//page_no��
		{
			$page_no = 1;
		}
		$start_num = $page_num * ($page_no-1);//ҳ��
		$sql = $query." limit $start_num,$page_num";
		$result = mysql_query($sql);
		$rows = @mysql_num_rows($result);
?>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
    <tr>
	<td>
	<div align="center">
	���������ļ�¼��
	<font color="#FF6600"><?php echo "$rows_total"?></font>
	��
	</div>
	</td>
	</tr>
</table>
</center>

<div align="center">
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
    <tr>
	<td width="5%"><div align="center">ID</div></td>
	<td width="25%"><div align="center">����</div></td>
	<td width="20%"><div align="center">����</div></td>
	<td width="20%"><div align="center">������</div></td>
	<td width="15%"><div align="center">״̬</div></td>
	<td width="15%" colspan="3"><div align="center">����</div></td>
	</tr>
	<?php
		for($i=0;$i<$rows;$i++)
		{
			mysql_data_seek($result,$i);
			$data = @mysql_fetch_array($result);
			$bookName = $data['BookName'];
			$bookauthor = $data['Author'];
			$bookpress = $data['Publisher'];
			$booktype = $data['Status'];
                        $bookid = $data['ID'];
	?>
	
	<tr height="30">
	<td width="5%"><div align="center"><?php echo "$bookid" ?></div></td>
	<td width="25%"><div align="center"><?php echo "$bookName" ?></div></td>
	<td width="20%"><div align="center"><?php echo "$bookauthor" ?></div></td>
	<td width="20%"><div align="center"><?php echo "$bookpress" ?></div></td>
	<td width="15%"><div align="center"><?php echo "$booktype" ?></div></td>	
	<td width="5%"><div align="center" class="button"><li><a href="borrow.php?bookid=<?php echo "$bookid"?>"><b>����</b></a></li></div></td>
	</tr>
	<?php
		}
		require_once "dbclose.php";
	?>
</table>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
<tr>
<td align="center">
<?php
echo "<a href='searchprocess.php?page_no=1'>��ҳ</a>";
echo "&nbsp;";
echo "<a href='searchprocess.php?page_no=".($page_no-1)."'>��һҳ</a>";
echo "&nbsp;";
echo "��".$page_no."ҳ [��".$page_total."ҳ]";
echo "&nbsp;";
echo "<a href='searchprocess.php?page_no=".($page_no+1)."&bookname=".$bookname."&author=".$author."&keyword=".$keyword."'>��һҳ</a>";
echo "&nbsp;";
echo "<a href='searchprocess.php?page_no=".$page_total."'>βҳ</a>";
?>
</td>
</tr>
</table>
</div>
</table>
</div>
<center>
	<table border="0" width="800" cellspacing="0" cellpadding="0">
	<tr>
		<td><hr size="1"></td>
	</tr>
	</table>
	<table border="1" width="800" height="50" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
		<td align="center" height="23" style="font-size:10.5pt">��Ȩ����(C)2013 �����к�����-�׹��Ĺ�˾ϵͳƽ̨��
		E-Mail:<a href="#">��ϵ����</a>
		<a href="library.php">������ҳ</a>		</td>
	</tr>
	</table>
</center>
</body>
</html>