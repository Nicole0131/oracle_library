<script>
<!--
	function shownologin()
	{
		window.alert ("����δ��¼�����ȵ�¼!");
		window.location.href='login.php';
		return false;
	}
	function shownocompetence()
	{
		window.alert ("Ŀǰֻ�ܽ���һ���������Ƿ���ͼ����δ�黹!");
		window.location.href='search.php';
		return true;
	}
	function shownothere()
	{
		window.alert ("ͼ���ѱ����!");
		window.location.href='search.php';
		return true;
	}
//-->
</script>

<?php
session_start();
$userid=$_SESSION['MM_Username'];
$bookid=$_GET['bookid'];
?>

<?php
	require_once "dbaccess.php";
	if(!isset($_SESSION['MM_Username']))
	{
            echo "<script language='javascript'>shownologin()</script>";
	    exit;
	}
	$bookId=$bookid;
	$loginUserID=$userid;
	$bookId=get_magic_quotes_gpc() ? $bookId : addslashes($bookId);
	#$bookId=$bookId;
	$LoginRS__query=sprintf("SELECT * FROM record WHERE user_ID='%s'",get_magic_quotes_gpc() ? $loginUserID : addslashes($loginUserID)); 
	$LoginRS = mysql_query($LoginRS__query) or die(mysql_error());
	$FoundUser = mysql_num_rows($LoginRS);
	if ($FoundUser) 
	{
	    require_once "dbclose.php";
	    echo "<script language='javascript'>shownocompetence()</script>";
	    exit;
	}
	$LoginRS__query=sprintf("SELECT * FROM record WHERE book_ID='%s'",get_magic_quotes_gpc() ? $bookId : addslashes($bookId)); 
	$LoginRS = mysql_query($LoginRS__query) or die(mysql_error());
	$FoundUser = mysql_num_rows($LoginRS);
	if ($FoundUser) 
	{
	    require_once "dbclose.php";
	    echo "<script language='javascript'>shownothere()</script>";
	    exit;
	}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="shortcut icon" href="favicon.ico" />
<title>ͼ�����</title>
<link href="lms.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
  <tr height="256">
    <td colspan="6"><img src="pics/banner.png" width="796" height="254"></td>
  </tr>
  <tr height="50">
    <td width="100"><div class="button"><li><a href="library.php"><b>��ҳ</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="search.php"><b>����ͼ��</b></a></li>
    </div></td>
	 <td width="130"><div class="button"><li><a href="login.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="bookmanage.php"><b>ͼ�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="usermanage.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="recordmanage.php"><b>���Ĺ���</b></a></li>
    </div></td>
  </tr>
</table>
</center>
<center>
<table border="1" width="800" height="30" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
  	<td width="234" align="center">
  	<img src="pics/position.png" width="16" height="16" align="absmiddle">&nbsp;���λ��	</td>
    <td><img src="pics/rightdir.png" width="16" height="16" align="absmiddle">[&gt;<a href="usermanage.php">ͼ�����</a>&lt;]</td>
	</tr>
</table>
</center>



<?php
$borrowdate=date('Y-m-d');
$day=date('d');
$mounth=date('m');
$newdate= mktime(12,0,0,$mounth,$day+21);
$returndate=date('Y-m-d',$newdate);
$LoginRS__query=sprintf("SELECT * FROM user WHERE user_ID='%s'",get_magic_quotes_gpc() ? $loginUserID : addslashes($loginUserID)); 
$result = mysql_query($LoginRS__query) or die(mysql_error());
$data = @mysql_fetch_array($result);
$adminName = $data['user_Admin'];
$LoginRS__query=sprintf("SELECT * FROM books WHERE ID='%s'",get_magic_quotes_gpc() ? $bookId : addslashes($bookId)); 
#$LoginRS__query=sprintf("SELECT * FROM books WHERE ID='%s'",$bookId); 
$result = mysql_query($LoginRS__query) or die(mysql_error());
$data = @mysql_fetch_array($result);
$bookName = $data['BookName'];
$_SESSION['Borrow_BookID']=$bookId;
$_SESSION['Borrow_UserID']=$loginUserID;
$_SESSION['Borrow_BorrowDate']=$borrowdate;
$_SESSION['Borrow_ReturnDate']=$returndate;
require_once "dbclose.php";
?>
	
<center>
<form action="borrowing.php" method="post" name="borrowing" >
<table border="1" width="800" height="30" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
  	<td width="234" rowspan="10" align="center"><img src="pics/book.png"  width="128" height="128"></td>
	<td>����ͼ�飺<?php echo $bookName; ?></td>
	</tr>
	<tr>
  	<td>�������ڣ�<?php echo $borrowdate; ?></td>
	</tr>
        <tr>
  	<td>Ӧ�����ڣ�<?php echo $returndate; ?></td>
	</tr>
	<tr>
  	<td>����Ա��<?php echo $adminName; ?></td>
	</tr>
	<tr>
	<td>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="submit" value="ȷ��" />
	</td>
	</tr>
	
</table>
</center>
<?php
	require_once "dbclose.php";
?>
<center>
	<table border="0" width="800" cellspacing="0" cellpadding="0">
	<tr>
		<td><hr size="1"></td>
	</tr>
	</table>
	<table border="1" width="800" height="50" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
		<td align="center" height="23" style="font-size:10.5pt">��Ȩ����(C)2013 �����к�����-�׹��Ĺ�˾ϵͳƽ̨��
		E-Mail:<a href="#">��ϵ����</a>
		<a href="library.php">������ҳ</a> </td>
	</tr>
	</table>
</center>
</body>
</html>