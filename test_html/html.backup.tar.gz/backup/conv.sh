#!/bin/bash

find ./ -type f -name "php$" -exec sed -i 's/charset=gb2312/charset=utf-8/g' {} \;


for file in `ls *.php`
do 
  iconv -f gb2312 -t utf-8 -o $file.tmp $file
done

for file in `ls *.tmp`
do
  mv $file ${file%.*}
done
