<script>
<!--
	function validateform()
	{
		if(document.userregist.userid.value == "")
		{
			window.alert ("�����������ʺ�!")
			return false;
		}
		if(document.userregist.username.value == "")
		{
			window.alert ("��������������!")
			return false;
		}
		if(document.userregist.userpasswordone.value == "")
		{
			window.alert ("���벻��Ϊ��!")
			return false;
		}
		if(document.userregist.userpasswordtwo.value == "")
		{
			window.alert ("���벻��Ϊ��!")
			return false;
		}
		if(document.userregist.usermanager.value == "")
		{
			window.alert ("���������ľ���!")
			return false;
		}
		if(document.userregist.useradmin.value == "")
		{
			window.alert ("���������Ĺ���Ա!")
			return false;
		}
		if(document.userregist.useremail.value == "")
		{
			window.alert ("��������������!")
			return false;
		}
		if(document.userregist.usertelephone.value == "")
		{
			window.alert ("��������ĵ绰!")
			return false;
		}
	}
//-->
</script>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="shortcut icon" href="favicon.ico" />
<title>�û�ע��</title>
<link href="lms.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
  <tr height="256">
    <td colspan="6"><img src="pics/banner.png" width="796" height="254"></td>
  </tr>
</table>
</center>
<center>
<table border="1" width="800" height="30" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
  	<td width="234" align="center">
  	<img src="pics/position.png" width="16" height="16" align="absmiddle">&nbsp;���λ��	</td>
        <td><img src="pics/rightdir.png" width="16" height="16" align="absmiddle">[&gt;  �û�ע��&lt;]</td>
	</tr>
</table>
</center>	
<center>
<form ACTION="userregister.php" METHOD="POST" name="userregist" onSubmit="return validateform( this.form )">
<table border="1" width="800" height="30" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
  	<td width="234" rowspan="10" align="center"><img src="pics/default.png" alt="�û���Ƭ" width="128" height="128"></td>
        <td >�ʺţ�</td>
	<td>
	<input type="text" name="userid" size="20"/>
	<font color="#8080C0">*</font><font size="2" color="#8080C0">   �������20�ַ�</font>
	</td>
	</tr>
	<tr>
  	<td>������</td>
	<td>
	<input type="text" name="username" size="20"/>
	<font color="#8080C0">*</font>
	</td>
	</tr>
	<tr>
  	<td>���룺</td>
	<td>
	<input type="password" name="userpasswordone" size="20"/>
	<font color="#8080C0">*</font><font size="2" color="#8080C0">   �������20λ</font>
	</td>
	</tr>
	<tr>
  	<td>�ظ����룺</td>
	<td>
	<input type="password" name="userpasswordtwo" size="20"/>
	<font color="#8080C0">*</font>
	</td>
	</tr>
	<tr>
  	<td>������</td>
	<td>
	<input type="text" name="usermanager" size="20"/>
	<font color="#8080C0">*</font>
	</td>
	</tr>
	<tr>
  	<td>���Ź���Ա��</td>
	<td>
	<input type="text" name="useradmin" size="20"/>
	<font color="#8080C0">*</font>
	</td>
	</tr>
	<tr>
  	<td>���䣺</td>
	<td>
	<input type="text" name="useremail" size="20"/>
	<font color="#8080C0">*</font>
	</td>
	</tr>
	<tr>
  	<td>�绰��</td>
	<td>
	<input type="text" name="usertelephone" size="20"/>
	<font color="#8080C0">*</font>
	</td>
	</tr>
	<tr>
	<td colspan="2" align="left">	
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="submit" width="200" value="ע��" />
	</td>
</tr>
</table>
</form>
</center>
<center>
	<table border="0" width="800" cellspacing="0" cellpadding="0">
	<tr>
		<td><hr size="1"></td>
	</tr>
	</table>
	<table border="1" width="800" height="50" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
		<td align="center" height="23" style="font-size:10.5pt">��Ȩ����(C)2013 �����к�����-�׹��Ĺ�˾ϵͳƽ̨��
		E-Mail:<a href="#">��ϵ����</a>
		<a href="library.php">������ҳ</a> </td>
	</tr>
	</table>
</center>
</body>
</html>