<script>
<!--
	function showsuccess()
	{
		window.alert ("����ɹ�!");
		window.location.href='library.php';
		return false;
	}
	function showfail()
	{
		window.alert ("��ͼ���Ѿ������һ�Σ���黹���½���!");
		window.location.href='library.php';
		return true;
	}
	function shownotnecessary()
	{
		window.alert ("��δ���黹ʱ�䣬��������!");
		window.location.href='library.php';
		return true;
	}
//-->
</script>
<?php
	require_once "dbaccess.php";
	$userid=$_GET['userid'];
	$Query="SELECT * FROM record WHERE user_ID='".$userid."'";
	$result = mysql_query($Query) or die(mysql_error());
	$data = @mysql_fetch_array($result);
	$borrowtime = $data['Layout'];
	echo $borrowtime;
	$borrowtimeU=strtotime($borrowtime);
	$day=date('d',$borrowtimeU);
	$mounth=date('m',$borrowtimeU);
	$olddate = mktime(12,0,0,$mounth,$day+18);
	$newdate= mktime(12,0,0,$mounth,$day+42);
	$returndate=date('Y-m-d',$newdate);
	$timestamp=time();
	if(($newdate > $timestamp)&&($timestamp>$olddate))
	{
		$Update="update record 	set ReturnDay='".$returndate."' where user_ID='".$userid."'";
		$result = mysql_query($Update) or die(mysql_error());
		echo "<script language='javascript'>showsuccess()</script>";
	}
	elseif($olddate > $timestamp)
	{
		echo "<script language='javascript'>shownotnecessary()</script>";
	}
	else
	{
		echo "<script language='javascript'>showfail()</script>";
	}
	require_once "dbclose.php";
?>