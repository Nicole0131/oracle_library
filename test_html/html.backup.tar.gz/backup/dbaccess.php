<?php
$link = mysql_connect('localhost', 'root', '19963')
    or die('Could not connect: ' . mysql_error());
mysql_select_db('db_library') or die('Could not select database');
mysql_query("SET NAMES 'gb2312'");	
?> 
