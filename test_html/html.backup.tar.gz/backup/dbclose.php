<?php
	// Closing connection
	mysql_close($link);
?>