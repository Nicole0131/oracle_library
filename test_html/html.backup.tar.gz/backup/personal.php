<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="shortcut icon" href="favicon.ico" />
<title>������Ϣ����</title>
<link href="lms.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
  <tr height="256">
    <td colspan="6"><img src="pics/banner.png" width="796" height="254"></td>
  </tr>
  <tr height="50">
    <td width="100"><div class="button"><li><a href="library.php"><b>��ҳ</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="search.php"><b>����ͼ��</b></a></li>
    </div></td>
	 <td width="130"><div class="button"><li><a href="login.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="bookmanage.php"><b>ͼ�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="usermanage.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="recordmanage.php"><b>���Ĺ���</b></a></li>
    </div></td>
  </tr>
</table>
</center>
<center>
<table border="1" width="800" height="30" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
  	<td width="234" align="center">
  	<img src="pics/position.png" width="16" height="16" align="absmiddle">&nbsp;���λ��	</td>
    <td><img src="pics/rightdir.png" width="16" height="16" align="absmiddle">[&gt;<a href="usermanage.php">������Ϣ����</a>&lt;]</td>
	</tr>
</table>
</center>

<?php 
	$userid = $_GET['userid'];
	require_once "dbaccess.php";	
	$query = "select * from books join record on books.ID = record.book_ID join user on user.user_ID = record.user_ID where record.user_ID = ";
	$query = $query."\"".$userid."\"";
	$result = mysql_query($query);
	if (!$result) {
    	die('Invalid query: ' . mysql_error());
	}
	$rows = mysql_num_rows($result);
	if($rows!=0)
	{
		$rows=$rows-1;
	
		mysql_data_seek($result,$rows);
		$data = @mysql_fetch_array($result);
?>	
<center>
<table border="1" width="800" height="30" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
   <tr>
	<td width="15%"><div align="center">����ͼ��</div></td>
	<td width="20%"><div align="center">�������</div></td>
	<td width="20%"><div align="center">Ӧ������</div></td>
	<td width="15%"><div align="center">����Ա</div></td>
	<td width="15%"><div align="center">����</div></td>
	<td width="15%" colspan="3"><div align="center">����</div></td>
	</tr>
	<?php
		$i=0;
		mysql_data_seek($result,$i);
		$data = @mysql_fetch_array($result);
		$username = $data['BookName'];
		$tel = $data['Layout'];
		$bname = $data['ReturnDay'];
		$returnday = $data['user_Admin'];
		$manager = $data['user_Manager'];
	?>
	
	<tr>
	<td width="15%"><div align="center"><?php echo "$username" ?></div></td>
	<td width="20%"><div align="center"><?php echo "$tel" ?></div></td>
	<td width="20%"><div align="center"><?php echo "$bname" ?></div></td>
	<td width="15%"><div align="center"><?php echo "$returnday" ?></div></td>
	<td width="15%"><div align="center"><?php echo "$manager" ?></div></td>
	

	<td width="10%"><div align="center">
	<a href="continue.php?userid=<?php echo "$userid"?>">
	<img src="pics/news.png" alt="����" border="0" width="30" height="30"></a></div></td>
  </tr>	
</table>
</center>
<?php
		}
	//require_once "freeresult.php";
	require_once "dbclose.php";
?>
<center>
	<table border="0" width="800" cellspacing="0" cellpadding="0">
	<tr>
		<td><hr size="1"></td>
	</tr>
	</table>
	<table border="1" width="800" height="50" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
		<td align="center" height="23" style="font-size:10.5pt">��Ȩ����(C)2013 �����к�����-�׹��Ĺ�˾ϵͳƽ̨��
		E-Mail:<a href="#">��ϵ����</a>
		<a href="library.php">������ҳ</a> </td>
	</tr>
	</table>
</center>
</body>
</html>