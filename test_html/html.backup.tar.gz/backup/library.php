<?php
session_start();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="shortcut icon" href="file:///D|/wamp/www/favicon.ico" />
<title>��ӭ���ʼ׹��Ĺ�˾ͼ���</title>
<link href="file:///D|/wamp/www/lms.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
  <tr height="256">
    <td colspan="6"><img src="pics/banner.png" width="796" height="254"></td>
  </tr>
</table>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
  <tr height="30" width="800">
  <td width="800" align = "right" >
  <?php
      if(isset($_SESSION['MM_Username']))
      {
	  $userid=$_SESSION['MM_Username'];
          echo "<font size=\"3\"><b>��ӭ��½</b></font>";
          echo "<a href=\"personal.php?userid=$userid\"><b>".$_SESSION['MM_Username']."</b></a>";
      }
      else
      {
	   echo "<a href=\"userregist.php\"><font size=\"3\"><b>ע��</b></font>";
      }
  ?>
  </td>
  </tr>
</table>
<table border="1" width="800" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
  <tr height="50">
    <td width="100"><div class="button"><li><a href="library.php"><b>��ҳ</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="search.php"><b>����ͼ��</b></a></li>
    </div></td>
	 <td width="130"><div class="button"><li><a href="login.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="bookmanage.php"><b>ͼ�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="usermanage.php"><b>�û�����</b></a></li>
    </div></td>
    <td width="130"><div class="button"><li><a href="recordmanage.php"><b>���Ĺ���</b></a></li>
    </div></td>
  </tr>
</table>
</center>
<center>
<table border="1" width="800" height="30" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
  	<td width="234" align="center">
	<img src="pics/date.png" width="16" height="16" align="absmiddle">
  	<?php
	  	$day = date("Y��m��d��");
		print("$day&nbsp;");
		switch(date("D")){
			case "Mon":echo "����һ";
			break;
			case "Tue":echo "���ڶ�";
			break;
			case "Wed":echo "������";
			break;
			case "Thu":echo "������";
			break;
			case "Fri":echo "������";
			break;
			case "Sat":echo "������";
			break;
			case "Sun":echo "������";
			break;	
		}
	?>
	</td>
    <td><marquee behavior="scroll" scrollamount="10" scrolldelay="200"><strong><font>ϵͳ��Ϣ:��ӭ���ʼ׹��Ĺ�˾ͼ���!</font></strong></marquee></td>
	</tr>
</table>
</center>
<center>
	<table border="0" width="800" cellspacing="0" cellpadding="0">
	<tr>
		<td><hr size="1"></td>
	</tr>
	</table>
	<table border="1" width="800" height="50" cellspacing="0" cellpadding="0" bgcolor="#E4E4E4" bordercolorlight="#C2C2C2" bordercolordark="#FFFFFF">
	<tr>
		<td align="center" height="23" style="font-size:10.5pt">��Ȩ����(C)2013 �����к�����-�׹��Ĺ�˾ϵͳƽ̨��
		E-Mail:<a href="#">��ϵ����</a>
		<a href="library.php">������ҳ</a> </td>
	</tr>
	</table>
</center>
</body>
</html>
